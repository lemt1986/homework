<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class avance extends Model
{
    //
}
