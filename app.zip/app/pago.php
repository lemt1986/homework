<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pago extends Model
{
    //
}
