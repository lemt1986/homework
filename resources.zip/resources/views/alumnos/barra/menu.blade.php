<div class="my-3"><a href="{{route('words')}}" ><img class="w-75" src="{{asset("img/ejercicio.png")}}"></a></div>
<div class="my-3 w-100" style="background-color: #c6c1c1"><img class="w-75" src="{{asset("img/chat.png")}}"></div>
<div class="my-3"><a href="{{route('words')}}"><img class="w-75" src="{{asset("img/avances.png")}}"></a></div>
<div class="my-3"><a href="{{route('words')}}"><img class="w-75" src="{{asset("img/pago.png")}}"></a></div>