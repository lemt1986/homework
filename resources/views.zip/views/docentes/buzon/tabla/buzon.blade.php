<div class="row my-2">
	<div class="col" style="color: #0bafb4;font-weight: bold;">Tema/Trabajo</div>
	<div class="col" style="color: #0bafb4;font-weight: bold;">Tipo de trabajo</div>
	<div class="col" style="color: #0bafb4;font-weight: bold;">Avances/entregables</div>
	<div class="col" style="color: #0bafb4;font-weight: bold;"></div>
	<div class="col"></div>
	<div class="col" style="color: #0bafb4;font-weight: bold;">Progreso de pago</div>
</div>
@foreach($exer as $exer)
<div class="row my-2">
	<div class="col" style="color: #4fafb2;">{{$exer->nombre_proyecto}} - {{$exer->materia}}</div>
	<div class="col" style="color: #4fafb2;">{{$exer->area}}</div>
	<div class="col" style="color: #4fafb2;"></div>
	<div class="col" style="color: #4fafb2;"><a type="button" class="" data-toggle="modal" data-target="#exampleModal">Chat</a></div>
	<div class="col" style="color: #4fafb2;"><a type="button" data-toggle="modal" data-target="#sub{{$exer->id}}">Subir Archivo</a></div>
	<div class="col" style="color: #4fafb2;">
		<div class="progress">
                        <div class="progress-bar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>  
	</div>
</div>
@endforeach


<!-- Modal -->
<div class="modal fade" id="sub{{$exer->id}}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Subir Archivo</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      	<form action="{{route('subir.store')}}" method="POST" enctype="multipart/form-data">
      		@csrf
      		<input type="hidden" name="exer_id" id="" value="{{$exer->id}}">
        	<input type="file" name="archivo" required>

        	<button type="submit" class="btn btn-primary">SUBIR</button>
      	</form>
        
      </div>
      
       
        
    
    </div>
  </div>
</div>