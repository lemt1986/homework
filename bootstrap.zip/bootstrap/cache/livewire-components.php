<?php return array (
  'chat-form' => 'App\\Http\\Livewire\\ChatForm',
  'chat-list' => 'App\\Http\\Livewire\\ChatList',
);