

<?php $__env->startSection('content'); ?>
<div class="jumbotron" style="background-color:#d9e022;">
    <h2 class="display-3" style="font-weight: bold;color: #4fafb2;"><?php echo e($word->word); ?></h2>
</div>

<?php if($word->id == 3): ?>
<?php echo $__env->make('alumnos.form.exercise', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif($word->id == 10): ?>
<?php echo $__env->make('alumnos.form.chat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\scue\resources\views/alumnos/form/formEjercicio.blade.php ENDPATH**/ ?>