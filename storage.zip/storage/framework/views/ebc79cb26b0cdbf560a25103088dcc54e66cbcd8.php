

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    
    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                                         
                    <?php endif; ?> 
<div class="row">
    <div class="col-sm-11">
<div class="container">
   
    <div class="row justify-content-center">
        <div class="col-md-12">
            <p class="display-3" style="color: #4fafb2;font-weight: bold;">Avances y entregas</p>

            <div class="row">
               
                <div class="col-md-4 mx-2" style="color: #4fafb2;font-weight: bold;">
                    Tema/Trabajo
                </div>
                <div class="col-md-3 mx-2" style="color: #4fafb2;font-weight: bold;">
                    Materia
                </div>
                <div class="col-md-1 mx-2">
                    
                </div>
                <div class="col-md-1 mx-2">
                    
                </div>
                <div class="col-md-2 mx-2">
                    
                </div>
                
                
            </div>
            <?php $__currentLoopData = $exer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class="row">
               
                <div class="col-md-4 mx-2" style="background-color: #6fafb4; color: white;font-weight: bold; border-radius:10px; border-radius:10px; ">
                    <?php echo e($exer->nombre_proyecto); ?>

                </div>
                <div class="col-md-3 mx-2" style="background-color: #d9d9d9; color: #4fafb2;font-weight: bold;border-radius:10px; border-radius:10px; ">
                    <?php echo e($exer->materia); ?> 
                </div>
                <div class="col-md-1 mx-2" style="background-color: #d9e022;border-radius:10px; border-radius:10px; ">
                    <a href="<?php echo e(route('subir.index', ['id_exer' => $exer->id])); ?>">Descargar</a>
                </div>
                <div class="col-md-1 mx-2" >
                    <form action="<?php echo e(route('avances.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id_teacher" value="<?php echo e($exer->teacher); ?>">
                        <button type="submit" style="background-color: #d5d5d5;color: #4fafb2;font-weight: bold;border-radius:10px; border-radius:10px;">Chat</button>
                    </form>
                    
                </div>
                <div class="col-md-2 mx-2">
                    <div class="progress">
                    <?php
                    //proceso para sacar el progreso
    
                    $date = new DateTime(); 
                    $fecha1= new DateTime($exer->fecha_entr);
                    $fecha2= new DateTime($exer->updated_at);
                    $diff = $fecha1->diff($fecha2);
                    $diff2 = $fecha1->diff($date);
                    $dia = $diff->days - $diff2->days;
                    $por = ($dia*100)/$diff->days;
    
                    ?>
                    <div class="progress-bar bg-warning" role="progressbar" style="width: <?php echo e($por); ?>%;" aria-valuenow="<?php echo e($por); ?>" aria-valuemin="0" aria-valuemax="100"><?php echo e(number_format($por)); ?>%</div> 
                    </div>                               
                </div>
                
                
            </div>
<!-- chat en tiempo real-->
            <?php if(isset($chat)): ?>

<ul class="list-group" style="position: fixed; bottom: 0px; right: 400px;">
  <li class="list-group-item active">
    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($user->name); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </li>
  <li class="list-group-item " style="height: 250px; overflow-y: scroll;" >
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount("chat-list", ["teacher" => $user->id])->dom;
} elseif ($_instance->childHasBeenRendered('0Sa3HLn')) {
    $componentId = $_instance->getRenderedChildComponentId('0Sa3HLn');
    $componentTag = $_instance->getRenderedChildComponentTagName('0Sa3HLn');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0Sa3HLn');
} else {
    $response = \Livewire\Livewire::mount("chat-list", ["teacher" => $user->id]);
    $dom = $response->dom;
    $_instance->logRenderedChild('0Sa3HLn', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
  </li>
  <li class="list-group-item">
    
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount("chat-form", ["chat" => $exer])->dom;
} elseif ($_instance->childHasBeenRendered('gzVsk1K')) {
    $componentId = $_instance->getRenderedChildComponentId('gzVsk1K');
    $componentTag = $_instance->getRenderedChildComponentTagName('gzVsk1K');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('gzVsk1K');
} else {
    $response = \Livewire\Livewire::mount("chat-form", ["chat" => $exer]);
    $dom = $response->dom;
    $_instance->logRenderedChild('gzVsk1K', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
    
  </li>
  
</ul>

<?php else: ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <!-- Button trigger modal -->

            

        </div>
    </div>
</div>
</div>
<div class="col px-0 sticky-right" style="background-color: #d9d9d9;">
        <div class="my-3"><a href="<?php echo e(route('words')); ?>" ><img class="w-75" src="<?php echo e(asset("img/ejercicio.png")); ?>"></a></div>
        <div class="my-3"><a href="<?php echo e(route('words.chats')); ?>"><img class="w-75" src="<?php echo e(asset("img/chat.png")); ?>"></a></div>
        <div class="my-3" style="background-color: #c6c1c1"><img class="w-75" src="<?php echo e(asset("img/avances.png")); ?>"></div>
        <div class="my-3"><a href="<?php echo e(route('pagos.index')); ?>"><img class="w-75" src="<?php echo e(asset("img/pago.png")); ?>"></a></div>
    </div>
</div>
</div>

<!-- Default dropup button -->


<script>
  

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\scue\resources\views/alumnos/avances/avance.blade.php ENDPATH**/ ?>