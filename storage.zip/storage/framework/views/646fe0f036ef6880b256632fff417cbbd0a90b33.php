<div class="row my-2">
	<div class="col" style="color: #0bafb4;font-weight: bold;">Tema/Trabajo</div>
	<div class="col" style="color: #0bafb4;font-weight: bold;">Tipo de trabajo</div>
	<div class="col" style="color: #0bafb4;font-weight: bold;">Avances/entregables</div>
	<div class="col" style="color: #0bafb4;font-weight: bold;"></div>
	<div class="col"></div>
	<div class="col" style="color: #0bafb4;font-weight: bold;">Progreso de pago</div>
</div>
<?php $__currentLoopData = $exer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row my-2">
	<div class="col" style="color: #4fafb2;"><?php echo e($exer->nombre_proyecto); ?> - <?php echo e($exer->materia); ?></div>
	<div class="col" style="color: #4fafb2;"><?php echo e($exer->area); ?></div>
	<div class="col" style="color: #4fafb2;">
    <?php if(isset($exer->archivo)): ?> 
    Entregas
    <?php else: ?>
    por entregar
    <?php endif; ?>
  </div>
	<div class="col" style="color: #4fafb2;"><a type="button" class="" data-toggle="modal" data-target="#exampleModal">Chat</a></div>
	<div class="col" style="color: #4fafb2;"><a type="button" data-toggle="modal" data-target="#sub<?php echo e($exer->id); ?>">Subir Archivo</a></div>
	<div class="col" style="color: #4fafb2;">
		<div class="progress">
      <?php
    //proceso para sacar el progreso
    
    $date = new DateTime(); 
    $fecha1= new DateTime($exer->fecha_entr);
    $fecha2= new DateTime($exer->updated_at);
    $diff = $fecha1->diff($fecha2);
    $diff2 = $fecha1->diff($date);
    $por = ($diff2->days*100)/$diff->days;
    
      ?>
      <div class="progress-bar bg-warning" role="progressbar" style="width: <?php echo e($por); ?>%;" aria-valuenow="<?php echo e($por); ?>" aria-valuemin="0" aria-valuemax="100"><?php echo e(number_format($por)); ?>%</div>
    </div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<!-- Modal -->
<div class="modal fade" id="sub<?php echo e($exer->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Subir Archivo</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      	<form action="<?php echo e(route('subir.store')); ?>" method="POST" enctype="multipart/form-data">
      		<?php echo csrf_field(); ?>
      		<input type="hidden" name="exer_id" id="" value="<?php echo e($exer->id); ?>">
        	<input type="file" name="archivo" required>

        	<button type="submit" class="btn btn-primary">SUBIR</button>
      	</form>
        
      </div>
      
       
        
    
    </div>
  </div>
</div>

<?php /**PATH C:\xampp\htdocs\scue\resources\views/docentes/buzon/tabla/buzon.blade.php ENDPATH**/ ?>