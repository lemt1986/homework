

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    
<div class="row">
    <div class="col-sm-11">
<div class="container">
    
    <div class="row">
        <div class="col-12">
            <h1 class="display-3" style="color: #4fafb2;font-weight: bold;">Detalle del servicio</h1>
        </div>
    </div>
    
    <?php $__currentLoopData = $exer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="col-md-6">
            <h4 style="color: #4fafb2;font-weight: bold;">Detalle</h4>
            
             <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" style="border-color: #51c3bc;border-radius: 10px;color:#4fafb2;" disabled>
                 <?php echo e($exer->area); ?>

                 <?php echo e($exer->ciclo); ?>

                 <?php echo e($exer->materia); ?>

             </textarea>
             
             <h4 style="color: #4fafb2;font-weight: bold;">Fecha de entrega</h4>
             
             <input type="text" name="" value="<?php echo e($exer->fecha_entr); ?>" class="py-3" style="border-color: #51c3bc;border-radius: 10px;text-align: center;color:#4fafb2;" disabled>
            
        </div>
        <div class="col-md-6">
            <h4 style="color: #4fafb2;font-weight: bold;">¿Tienes código promocional?</h4>
            <input type="text" name="" value="" class="py-3" style="border-color: #51c3bc;border-radius: 10px;text-align: center;color:#4fafb2;" >

            <div class="form-group row">
                <label for="inputEmail3" class="col-sm-6 col-form-label" style="color: #4fafb2;font-weight: bold;">Subtotal</label>
                <div class="col-sm-6">
                   
                    <input class="form-control" id="valor" type="number"  value="<?php echo e($exer->ofert_fin); ?>" style="border-color: #51c3bc;border-radius: 10px;text-align: center;color:#4fafb2;" disabled onkeyUp="calcular();">
                    
                </div>
            </div>
            <div class="form-group row">
                <label for="inputEmail3" class="col-sm-6 col-form-label" style="color: #4fafb2;">*Descuento</label>
                <div class="col-sm-6">
                    10%
                </div>
            </div>
            <div class="form-group row">
                <label for="inputEmail3" class="col-sm-6 col-form-label" style="color: #4fafb2;font-weight: bold;">Total a pagar</label>
                <div class="col-sm-6">

                    <span class="form-control" id="result1" style="border-color: #51c3bc;border-radius: 10px;text-align: center;color:#4fafb2;"></span>
                    
                </div>
            </div>
            
        </div>
    </div>
    <div> 
      <?php if(auth::user()->cod == '+51'): ?> 
        <form action="<?php echo e(route('pay')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="precio" value="<?php echo e($exer->ofert_fin); ?>">
            <input type="hidden" name="id" value="<?php echo e($exer->id); ?>">
            <button type="submit" class="btn btn-warning mb-2 float-right">Pagar mercado pago</button>
        </form>
        <?php else: ?>
        <form action="<?php echo e(route('paypal/pay')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="precio" value="<?php echo e($exer->ofert_fin); ?>">
            <input type="hidden" name="id" value="<?php echo e($exer->id); ?>">
            <button type="submit" class="btn btn-warning mb-2 float-right">Pagar paypal</button>
        </form>
        <?php endif; ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         

</div>        
    </div>
    <div class="col px-0 sticky-right" style="background-color: #d9d9d9;">
        <div class="my-3"><a href="<?php echo e(route('words')); ?>" ><img class="w-75" src="<?php echo e(asset("img/ejercicio.png")); ?>"></a></div>
        <div class="my-3 w-100" ><a href="<?php echo e(route('words.chats')); ?>"><img class="w-75" src="<?php echo e(asset("img/chat.png")); ?>"></a></div>
        <div class="my-3"><a href="<?php echo e(route('avances.index')); ?>"><img class="w-75" src="<?php echo e(asset("img/avances.png")); ?>"></a></div>
        <div class="my-3" style="background-color: #c6c1c1"><img class="w-75" src="<?php echo e(asset("img/pago.png")); ?>"></div>
    </div>
</div>
</div>
<script>
   
  //Obtienes el valor
  var valor = document.getElementById("valor").value;

  var result= document.getElementById('result');

  //le descuentas el 8% y lo agregas al HTML
  var descuento = valor - (parseInt(valor)*0.10) ;

  //agrega los resultados al DOM
  result.innerHTML = descuento;

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\scue\resources\views/alumnos/postul/exercise.blade.php ENDPATH**/ ?>