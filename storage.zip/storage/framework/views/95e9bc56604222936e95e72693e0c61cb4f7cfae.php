<div class="row my-3">
    <div class="col" style="color: #4fafb2;font-weight: bold;">Alumno</div>
    <div class="col"></div>
    <div class="col"></div>
    <div class="col" style="color: #4fafb2;font-weight: bold;">Fecha de entrega</div>
    <div class="col" style="color: #4fafb2;font-weight: bold;">Confirmar fecha</div>
    <div class="col" style="color: #4fafb2;font-weight: bold;">Tu tarifa</div>
    <div class="col" style="color: #4fafb2;font-weight: bold;">Usted recibirá</div>
    <div class="col"></div>

</div>
<?php $__currentLoopData = $exer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row my-3">
    <di class="col-md-6">
        <div class="row">
            <div class="col-md-3 text-info"><img class="img-fluid w-25" src="<?php echo e(asset("img/avatar.jpg")); ?>"><?php echo e($exer->name); ?></div>
            <div class="col-md-3 text-info"><a href="<?php echo e(route('exercises.ofert', ['id' => $exer->id])); ?>">Detalle</a></div>
            <div class="col-md-3 text-info"> <a href="../storage/app/<?php echo e($exer->archivo); ?>" download="tarea">Descargar tarea</a></div>
            <div class="col-md-3 text-info"><?php echo e($exer->fecha_entr); ?></div>
        </div>
    </di>
    <di class="col-md-6">
        <form action="<?php echo e(route('postulation.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
            <input type="hidden" name="user_id" value="<?php echo e($exer->user_id); ?>">
            <input type="hidden" name="teacher_id" value="<?php echo e(Auth::user()->id); ?>">
            <input type="hidden" name="exer_id" value="<?php echo e($exer->id); ?>">
        <div class="row">
            <div class="col-md-4 text-info"><input type="date" name="fecha"  class="px-2 w-100" ></div>
            <div class="col-md-3 text-info mx-2">S/ <input type="text" id="valor" name="precio" class="w-75" onkeyUp="calcular();" ></div>
            <div class="col-md-2 text-info">S/ <span id="result"></span></div>
            <div class="col-md-2 text-info"><button type="submit" class="btn btn-success mx-auto d-block ">ENVIAR</button></div> 
        </div>
        </form>
    </di>
</div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
   function calcular(){
    //Obtienes el valor
  var valor = document.getElementById("valor").value;

  var result= document.getElementById('result');

  //le descuentas el 8% y lo agregas al HTML
  var descuento = valor - (parseInt(valor)*29.42/100) ;

  //agrega los resultados al DOM
  result.innerHTML = descuento;
   }
  

</script><?php /**PATH C:\xampp\htdocs\scue\resources\views/docentes/tabla/ofertas.blade.php ENDPATH**/ ?>