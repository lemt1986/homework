

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
<div class="row">
    <div class="col-sm-11">
<div class="container">
    
    <div class="row">
        <div class="col-12">
        	<h1 class="display-3" style="color: #4fafb2;font-weight: bold;">Ofertas de trabajo?</h1>
            <?php echo $__env->make('docentes.tabla.ofertas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
        </div>
    </div>

</div>
</div>
    <div class="col px-0 sticky-right" style="background-color: #d9d9d9;">
        <div class="my-3" style="background-color: #c6c1c1"><a><img class="w-75" src="<?php echo e(asset("img/ofert_doc.png")); ?>"></a></div>
        <div class="my-3 w-100" ><a href="<?php echo e(route('exercises.create')); ?>"><img class="w-75" src="<?php echo e(asset("img/buzon.png")); ?>"></a></div>
        <div class="my-3"><a href="<?php echo e(route('cuentas.index')); ?>"><img class="w-75" src="<?php echo e(asset("img/retiro.png")); ?>"></a></div>
        
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_d', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\scue\resources\views/docentes/oferta.blade.php ENDPATH**/ ?>