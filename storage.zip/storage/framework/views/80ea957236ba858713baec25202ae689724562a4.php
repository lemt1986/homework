<div class="">

     <input type="hidden" 
            wire:model="usuario" 
            class="form-control"  
            id="usuario" 
            >
            <input type="hidden" 
            wire:model="teacher" 
            class="form-control"  
            id="teacher" 
            >

     <div style="position: absolute;"
            class="alert alert-success collapse" 
            role="alert" 
            id="avisoSuccess"       
            >Se ha enviado
    </div> 

    <input type="text" class="form-control" 
            wire:model="mensaje" 
            wire:keydown.enter="enviarMensaje" 
            aria-label="Recipient's username" 
            aria-describedby="button-addon2"
            id="mensaje"
            placeholder="Escribe tu mensaje">

    <div class="input-group-append">
        <button class="btn btn-outline-info" 
                wire:click="enviarMensaje"
                wire:loading.attr="disabled"
                wire:offline.attr="disabled" 
                id="button-addon2">Enviar</button>
                
    </div> 
           
</div>
    
    <script>
                 
        // Esto lo recibimos en JS cuando lo emite el componente
        // El evento "enviadoOK"
         
  //window.document.getElementById("usuario").value = valor;

            window.livewire.on('enviadoOK', function () {
                $("#avisoSuccess").show();                
                setTimeout(function(){ $("#avisoSuccess").hide("slow"); }, 3000);                                
            });
        
        
    </script>

<?php /**PATH C:\xampp\htdocs\scue\resources\views/livewire/chat-form.blade.php ENDPATH**/ ?>