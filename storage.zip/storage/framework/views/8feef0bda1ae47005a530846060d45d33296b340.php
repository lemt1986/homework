<?php $__env->startSection('contentido'); ?>
<section style="background-color: #4fcdcc;">
    <div class="container py-3">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="border-radius: 15px;">
                
                <div class="card-body" >
                    <img src="<?php echo e(asset("img/Logo_2.png")); ?>" class="mx-auto d-block img-fluid w-25">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row w-50 mx-auto">
                            <h4 for="email" class="text-md-right mx-auto" style="color: #348fa9;"><strong>Usuario</strong></h4>

                            <div class="col-md-12 ">
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus style="background-color: #14a6af; text-align: center; color: white; font-size: 4vh;">

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row w-50 mx-auto">
                            <h4 for="password" class="text-md-right mx-auto" style="color: #348fa9;"> <strong>Contraseña</strong></h4>

                            <div class="col-md-12 ">
                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" style="background-color: #14a6af; text-align: center; color: white; font-size: 4vh;">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row w-50 mx-auto">
                            <div class="col-md-12" align="center">
                                <button type="submit" class="btn" style="color: #d9e022;">
                                    <h2 align="center"><strong>INGRESAR</strong></h2>
                                </button>

                            </div>
                        </div>

                        <div class="form-group row w-50 mx-auto">
                            <div class="col-md-12 offset-md-4">
                                
                                <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                         Olvide mi contraseña
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>

                         <div class="form-group row mb-0 mx-auto">
                            <div class="col-md-12" align="center">
                                <a href="<?php echo e(route('register')); ?>" class="btn" style="color: #14a6af;">
                                   <h2><strong>¿No tienes una cuenta? Registrate</strong></h2> 
                                </a>

                            </div>
                        </div>
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_ini', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\scue\resources\views/auth/login.blade.php ENDPATH**/ ?>