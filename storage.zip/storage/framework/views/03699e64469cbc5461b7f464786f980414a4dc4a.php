

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    
<div class="row">
    <div class="col-sm-11">
<div class="container">
    <?php if(session('mensaje')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('mensaje')); ?>

                        </div>
                             <?php elseif(session('mensaje1')): ?>     
                             <div class="alert alert-danger">
                               <?php echo e(session('mensaje1')); ?>

                             </div>                 
                    <?php endif; ?> 
    <div class="row justify-content-center">
        <div class="col-md-12">
            <p class="display-3" style="color: #4fafb2;font-weight: bold;">¿Qué tipo de trabajo necesito?</p>

            <div class="row">
                <?php $__currentLoopData = $words; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $word): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <a href="<?php echo e(route('words.show', $word->id)); ?>">
                        <img class="img-fluid mx-auto d-block h-50" src="../storage/app/<?php echo e($word->img); ?>"><br>
                        <p align="center" style="color: #4fafb2;font-weight: bold;"><?php echo e($word->word); ?></p>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
            
        </div>
    </div>
</div>
</div>
<div class="col px-0 sticky-right" style="background-color: #d9d9d9;">
        <div class="my-3" style="background-color: #c6c1c1"><a href="#" ><img class="w-75" src="<?php echo e(asset("img/ejercicio.png")); ?>"></a></div>
        <div class="my-3"><a href="<?php echo e(route('words.chats')); ?>"><img class="w-75" src="<?php echo e(asset("img/chat.png")); ?>"></a></div>
        <div class="my-3"><a href="<?php echo e(route('avances.index')); ?>"><img class="w-75" src="<?php echo e(asset("img/avances.png")); ?>"></a></div>
        <div class="my-3"><a href="<?php echo e(route('pagos.index')); ?>"><img class="w-75" src="<?php echo e(asset("img/pago.png")); ?>"></a></div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\scue\resources\views/alumnos/ejercicios.blade.php ENDPATH**/ ?>