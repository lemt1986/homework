<div class="mt-3">

    <div class="card">        
        <div class="card-body">
             <?php $__currentLoopData = $mensajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mensaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
                <div>
                    
                    <?php if($mensaje->send != $usuario): ?>
                        <?php if($mensaje->usuario != $teacher): ?>
                        <?php else: ?>
                        <div class="alert alert-warning h-50" style="margin-right: 50px;">
                            <br><span class="text-muted"><?php echo e($mensaje->mensaje); ?></span>
                        </div>
                        <?php endif; ?>
                    <?php else: ?>

                        <div class="alert alert-success h-50" style="margin-left: 50px;">
                            <br><span class="text-muted"><?php echo e($mensaje->mensaje); ?></span>
                        </div>
                    <?php endif; ?>
                    
                </div>        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </div>
    </div>    

    <script>
        
        // Enable pusher logging - don't include this in production
        Pusher.logToConsole = true;
  
        var pusher = new Pusher('<?php echo e(env('PUSHER_APP_KEY')); ?>', {
            cluster: '<?php echo e(env('PUSHER_APP_CLUSTER')); ?>',
            forceTLS: true
        });
        
        var channel = pusher.subscribe('chat-channel');
        
        channel.bind('chat-event', function(data) {  
         window.livewire.emit('mensajeRecibido', data);
        });
        
        setTimeout(function(){ window.livewire.emit('solicitaUsuario'); }, 100);
    </script>

</div>
<?php /**PATH C:\xampp\htdocs\scue\resources\views/livewire/chat-list.blade.php ENDPATH**/ ?>