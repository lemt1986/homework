

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
<div class="row">
    <div class="col-sm-11">
<div class="container">
    <div class="row">
        <div class="col-12">
          <h1 class="display-3" style="color: #4fafb2;font-weight: bold;">Detalle</h1>
            
        </div>
    </div>
    <?php $__currentLoopData = $exer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
      <div class="col-md-6">
        <p style="color: #4fafb2;"><strong style="color: #4fafb2;font-weight: bold;">Tipo de trabajo:</strong> <?php echo e($exer->area); ?></p>
        <p style="color: #4fafb2;"><strong style="color: #4fafb2;font-weight: bold;">Año:</strong> <?php echo e($exer->ciclo); ?></p>
        <p style="color: #4fafb2;"><strong style="color: #4fafb2;font-weight: bold;">Curso/materia:</strong> <?php echo e($exer->materia); ?></p>
        <p style="color: #4fafb2;"><strong style="color: #4fafb2;font-weight: bold;">Tema:</strong> <?php echo e($exer->nombre_proyecto); ?></p>
        <p style="color: #4fafb2;"><strong style="color: #4fafb2;font-weight: bold;">Fecha de entrega:</strong> <?php echo e($exer->fecha_entr); ?></p>
        <p style="color: #4fafb2;"><strong style="color: #4fafb2;font-weight: bold;">Descripción del proyecto:</strong> <?php echo e($exer->descripcion); ?></p>
      </div>
      <div class="col-md-6">
        <p style="color: #4fafb2;"><strong style="color: #4fafb2;font-weight: bold;">Número de páginas:</strong> <?php echo e($exer->n_pag); ?></p>
        <p style="color: #4fafb2;"><strong style="color: #4fafb2;font-weight: bold;">Interlineado:</strong> <?php echo e($exer->interli); ?></p>
        <p style="color: #4fafb2;"><strong style="color: #4fafb2;font-weight: bold;">Bibliografía:</strong> <?php echo e($exer->bibliografia); ?></p>
        <p style="color: #4fafb2;"><strong style="color: #4fafb2;font-weight: bold;">Referencias:</strong> <?php echo e($exer->referencia); ?></p>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

  
</div>
</div>
    <div class="col px-0 sticky-right" style="background-color: #d9d9d9;">
        <div class="my-3" style="background-color: #c6c1c1"><a href="" ><img class="w-75" src="<?php echo e(asset("img/ofert_doc.png")); ?>"></a></div>
        <div class="my-3 w-100" ><a href="<?php echo e(route('exercises.create')); ?>"><img class="w-75" src="<?php echo e(asset("img/buzon.png")); ?>"></a></div>
        <div class="my-3"><a href=""><img class="w-75" src="<?php echo e(asset("img/retiro.png")); ?>"></a></div>
        
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\scue\resources\views/docentes/proyecto/postular.blade.php ENDPATH**/ ?>